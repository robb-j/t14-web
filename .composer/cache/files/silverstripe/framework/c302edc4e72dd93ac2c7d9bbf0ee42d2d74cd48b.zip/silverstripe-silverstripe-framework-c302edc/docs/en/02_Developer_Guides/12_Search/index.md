title: Search
summary: Provide your users with advanced search functionality.
introduction: Give users the ability to search your applications. Fulltext search for Page Content (and other attributes like "Title") can be easily added to SilverStripe.

See the [Site Search Tutorial](/tutorials/site_search) for a detailed walk through of adding basic Search to your
website.

[CHILDREN]