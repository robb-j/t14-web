{
    "LeftAndMain.CONFIRMUNSAVED": "Určitě chcete opustit navigaci z této stránky?\n\nUPOZORNĚNÍ: Vaše změny nebyly uloženy.\n\nStlačte OK pro pokračovat, nebo Cancel, zůstanete na této stránce.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "UPOZORNĚNÍ: Vaše změny nebyly uloženy.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Skutečně chcete smazat %s skupiny?",
    "ModelAdmin.SAVED": "Uloženo",
    "ModelAdmin.REALLYDELETE": "Skutečně chcete smazat?",
    "ModelAdmin.DELETED": "Smazáno",
    "ModelAdmin.VALIDATIONERROR": "Chyba platnosti",
    "LeftAndMain.PAGEWASDELETED": "Tato stránka byla smazána. Pro editaci stránky, vyberte ji vlevo."
}