{
    "LeftAndMain.CONFIRMUNSAVED": "Czy na pewno chcesz kontynuować nawigację poza tą stronę?\n\nUWAGA: Twoje zmiany nie zostały zapisane.\n\nWciśnij OK aby kontynuować, wciśnij Anuluj aby pozostać na tej stronie.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "UWAGA: Twoje zmiany nie zostały zapisane.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Czy na pewno chcesz usunąć %s grup?",
    "ModelAdmin.SAVED": "Zapisano",
    "ModelAdmin.REALLYDELETE": "Na pewno usunąć?",
    "ModelAdmin.DELETED": "Usunięto",
    "ModelAdmin.VALIDATIONERROR": "Niepoprawne dane",
    "LeftAndMain.PAGEWASDELETED": "Ta strona została usunięta. Wybierz stronę z listy aby rozpocząć edycję."
}