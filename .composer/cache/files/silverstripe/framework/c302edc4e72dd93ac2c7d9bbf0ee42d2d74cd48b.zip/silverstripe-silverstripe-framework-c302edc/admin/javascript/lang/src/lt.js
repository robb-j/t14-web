{
    "LeftAndMain.CONFIRMUNSAVED": "Ar tikrai norite išeiti iš šio puslapio?\n\nDĖMESIO: Jūsų pakeitimai neišsaugoti.\n\nNorėdami tęsti, spauskite OK, jeigu norite likti, spauskite Cancel.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "DĖMESIO: Jūsų pakeitimai neišsaugoti.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Ar tikrai norite ištrinti %s grupes?",
    "ModelAdmin.SAVED": "Išsaugota",
    "ModelAdmin.REALLYDELETE": "Ar tikrai norite ištrinti?",
    "ModelAdmin.DELETED": "Ištrinta",
    "ModelAdmin.VALIDATIONERROR": "Tikrinimo klaida",
    "LeftAndMain.PAGEWASDELETED": "Šis puslapis ištrintas. Norėdami redaguoti puslapį, pasirinkite jį kairėje."
}