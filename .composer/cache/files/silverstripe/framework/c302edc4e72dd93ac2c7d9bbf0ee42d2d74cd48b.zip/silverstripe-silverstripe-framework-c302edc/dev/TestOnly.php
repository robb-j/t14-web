<?php
/**
 * Classes that implement TestOnly are only to be used during testing
 * @package framework
 * @subpackage testing
 */
interface TestOnly {

}

