{
    "LeftAndMain.CONFIRMUNSAVED": "Är du säker på att du vill lämna denna sida?\n\nVARNING: Dina ändringar har inte sparats.\n\nTryck OK för att lämna sidan eller Avbryt för att stanna på aktuell sida.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "WARNING: Your changes have not been saved.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Vill du verkligen radera %s grupper?",
    "ModelAdmin.SAVED": "Sparad",
    "ModelAdmin.REALLYDELETE": "Vill du verkligen radera?",
    "ModelAdmin.DELETED": "Raderad",
    "ModelAdmin.VALIDATIONERROR": "Valideringsfel",
    "LeftAndMain.PAGEWASDELETED": "Sidan raderades. För att redigera en sida, välj den från menyn till vänster."
}