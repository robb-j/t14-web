{
    "LeftAndMain.CONFIRMUNSAVED": "Sunteți sigur că doriți să părăsiți pagina?\n\nAVERTISMENT: Modificările nu au fost salvate.\n\nApăsați OK pentru a continua, sau Anulați pentru a rămâne pe pagina curentă.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "AVERTISMENT: Modificările nu au fost salvate.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Sigur doriți să ștergeți grupurile %s?",
    "ModelAdmin.SAVED": "Salvat",
    "ModelAdmin.REALLYDELETE": "Sigur doriți să ștergeți?",
    "ModelAdmin.DELETED": "Șters",
    "ModelAdmin.VALIDATIONERROR": "Eroare de validare",
    "LeftAndMain.PAGEWASDELETED": "Această pagină a fost ștearsă. Pentru a edita pagina, selectați-o din stânga."
}