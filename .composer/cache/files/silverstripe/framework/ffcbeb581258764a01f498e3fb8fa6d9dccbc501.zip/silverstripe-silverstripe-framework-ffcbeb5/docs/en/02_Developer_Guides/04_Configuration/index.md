title: Configuration
summary: SilverStripe provides several ways to store and modify your application settings. Learn about site wide settings and the YAML based configuration system.
introduction:  SilverStripe provides several ways to store and modify your application settings. Learn about site wide settings and the YAML based configuration system.

[CHILDREN]