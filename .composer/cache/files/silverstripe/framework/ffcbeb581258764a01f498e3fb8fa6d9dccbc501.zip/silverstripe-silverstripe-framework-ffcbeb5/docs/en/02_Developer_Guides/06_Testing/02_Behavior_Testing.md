title: Behavior Testing
summary: Describe how your application should behave in plain text and run tests in a browser.

# Behavior Testing

For behavior testing in SilverStripe, check out 
[SilverStripe Behat Documentation](https://github.com/silverstripe-labs/silverstripe-behat-extension/).
