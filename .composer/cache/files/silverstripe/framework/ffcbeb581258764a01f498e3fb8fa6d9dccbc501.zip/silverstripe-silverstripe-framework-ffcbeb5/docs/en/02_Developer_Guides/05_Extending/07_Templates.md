title: Custom Templates
summary: Override templates from core and modules in your application

# Custom Templates

See [Template Inheritance](../templates).

## Form Templates

See [Form Templates](../forms/form_templates).