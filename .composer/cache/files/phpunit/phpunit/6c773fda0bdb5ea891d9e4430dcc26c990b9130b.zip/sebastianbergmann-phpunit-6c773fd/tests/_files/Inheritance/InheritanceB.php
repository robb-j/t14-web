<?php

class InheritanceB extends PHPUnit_Framework_TestCase
{
    public function testSomething()
    {
    }
}
