<?php
class NonStatic
{
    public function suite()
    {
        return;
    }
}
